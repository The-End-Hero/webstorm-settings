import * as React from 'react';
import { observer } from 'mobx-react';
import appContext from '@/modules/map-edit/__private__/appContext';

const prefixCls = '';
const ${NAME} = observer(() => {
  const { routeStore } = React.useContext(appContext.getContext());
  return (
    <div className={prefixCls}>
    </div>
  );
});

export default ${NAME};
